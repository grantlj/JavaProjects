package ui;

public class UIMain {
  public static void main(String[] args)
  {
	 CalculatorFrame cf=new CalculatorFrame();
  }
}
